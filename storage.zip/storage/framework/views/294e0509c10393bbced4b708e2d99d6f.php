   <?php $__env->startSection('content'); ?>
   <!-- Modal -->
    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
         <!-- Discount Modal -->
        <div class="fixed inset-0 flex items-center justify-center bg-opacity-50">
          <div class="bg-white rounded-lg p-6 w-1/3">
            <div class="flex justify-between items-center mb-4">
              <h3 class="text-lg font-bold text-yellow-500"><i class="fas fa-tags mr-2"></i>Discount Pesanan</h3>
              <button class="text-gray-500"><i class="fas fa-times"> </i></button>
            </div>
            <div class="mb-4">
              <label class="block text-gray-700 mb-2">Masukkan jumlah diskon</label>
              <div class="flex items-center">
                <input class="w-full p-2 border border-gray-300 rounded-l" placeholder="0" type="text"/>
                <span class="bg-gray-200 p-2 rounded-r">%</span>
              </div>
            </div>
            <div class="mb-4">
              <label class="block text-gray-700 mb-2">Masukkan kode voucher</label>
              <input class="w-full p-2 border border-gray-300 rounded" placeholder="Kode Voucher" type="text"/>
            </div>
            <button class="bg-green-500 text-white px-4 py-2 rounded w-full">Pakai Diskon</button>
          </div>
        </div>
      </div>
    </div>
    <div class="modal-footer">
      <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
      <button type="button" class="btn btn-primary">Save changes</button>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?><?php /**PATH C:\POS2\resources\views/modal/tambahdiskon.blade.php ENDPATH**/ ?>