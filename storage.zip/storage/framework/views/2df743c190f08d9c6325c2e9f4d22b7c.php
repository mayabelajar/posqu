

<?php $__env->startSection('content'); ?>
      <div class="dropdown">
            <button class="btn btn-secondary dropdown-toggle" type="button" data-toggle="dropdown" aria-expanded="false">
                Laporan
            </button>
            <div class="dropdown-menu">
                <a class="dropdown-item" href="<?php echo e(url('/harian')); ?>">Hari Ini</a>
                <a class="dropdown-item" href="<?php echo e(url('/bulanan')); ?>">Bulan</a>
                <a class="dropdown-item" href="<?php echo e(url('/tahunan')); ?>">Tahun</a>
            </div>
            </div>
        </div>
        <div class="container">
    <div class="row">
    <div class="bulanan">
<canvas id="myChart"
 width="400" height="200"></canvas>

  <script> 

    const ctx = document.getElementById('myChart').getContext('2d');
    var myChart = new Chart(ctx, {
      type: 'line',
      data: {
        labels: ['Januari', 'Feburari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'],
        datasets: [{
          label: 'My First Dataset',
          data: [10000000, 15000000, 20000000, 20000000, 25000000, 35000000, 40000000, 45000000, 50000000, 45000000, 40000000, 50000000],
          backgroundColor: 'rgba(255, 99, 132, 0.2)',
          borderColor: 'rgba(255, 99, 132, 1)',
          borderWidth: 1
        }]
      },
      options: {
        scales: {
          y: {
            beginAtZero: true
          }
        }
      }
    });
  </script>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\POS2\resources\views/laporan/bulanan.blade.php ENDPATH**/ ?>